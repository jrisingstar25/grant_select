<?php

error_reporting(E_ALL & ~E_NOTICE);

function validate_sip2_card($card_number, $sip_host, $sip_port, $login_user = '', $login_pass = '') {
    $socket = fsockopen($sip_host, $sip_port, $errno, $errstr, 10);
    if (!$socket) {
        return ['error' => "Connection failed: $errstr ($errno)"];
    } else {
        echo "SOCKET CONNECTED<br>";
    }

    // Example login message (9300 = login message, CN=login user, CO=login password)
    $login_msg = "9300CN{$login_user}|CO{$login_pass}|\r";
    fwrite($socket, $login_msg);
    $login_response = fgets($socket); // Read login response

    echo "LOGIN RESPONSE: $login_response<br>";
    flush();

    if ($login_response == 941) {   // 941 response is a successful login to the SIP2 server

        // Create Patron Status message (23)
        // Format: 23<language><transaction date>AO<login username>|AA<patron identifier>|AC<terminal password>|
        $transaction_date = date('Ymd    His');  // the 4 spaces between "Ymd" and "His" are important
        $msg = "23000" . $transaction_date . "AO{$login_user}|AA{$card_number}|AC{$login_pass}|\r";

        fwrite($socket, $msg);

        $card_valid_response = fgets($socket);
    }

    echo "CARD VALID RESPONSE: $card_valid_response<br>";
    flush();

    fclose($socket);


    // SIP2 response starts with 24 if successful Patron Status response
    if (str_contains($card_valid_response, '|BLY|')) {
        // "|BLY|" in the response indicates that the card number matches an existing card number
        $valid = 1;
        return [
            'card_number' => $card_number,
            'valid' => $valid,
            'raw_response' => $card_valid_response
        ];
    }

    return ['error' => 'Invalid response or bad card', 'raw_response' => $card_valid_response];
}


$result = validate_sip2_card(
    '21208049411147',      // Card Number
    'evergreen.lib.in.us', // SIP2 Host
    6001,               // Port
    'putnm-sip2',         // Login user (AO)
    '2119'          // Terminal password (AC)
);

if (!empty($result['error'])) {
    echo "Error: " . $result['error'];
} else {
    echo $result['valid'] ? "Card is valid." : "Card is invalid.";
}

?>
